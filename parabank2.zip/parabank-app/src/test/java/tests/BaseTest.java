package tests;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;
import pages.AccountLogin;

import java.time.Duration;

public class BaseTest {
    protected WebDriver driver;
    protected WebDriverWait wait;
    protected AccountLogin accountLogin;
    protected final String BASE_URL = "https://parabank.parasoft.com/parabank/index.htm";

    @BeforeClass(alwaysRun = true)
    public void beforeClass() {
        try {
            io.github.bonigarcia.wdm.WebDriverManager.chromedriver().setup();
        } catch (Exception e) {
            System.err.println("WebDriverManager failed: " + e.getMessage());
        }

        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");
        driver = new ChromeDriver(options);
        wait = new WebDriverWait(driver, Duration.ofSeconds(8));
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
    }


    @BeforeMethod(alwaysRun = true)
    public void beforeMethod() {
        driver.get(BASE_URL);
        accountLogin = new AccountLogin(driver);
    }

    @AfterClass(alwaysRun = true)
    public void afterClass() {
        if (driver != null) {
            driver.quit();
        }
    }

    protected void doLogoutIfPresent() {
        try {
            if (!driver.findElements(By.linkText("Log Out")).isEmpty()) {
                driver.findElement(By.linkText("Log Out")).click();
            } else if (!driver.findElements(By.linkText("Logout")).isEmpty()) {
                driver.findElement(By.linkText("Logout")).click();
            }
        } catch (Exception ignored) {
        }
    }
}
