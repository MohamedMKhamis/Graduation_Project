package pages;

import org.openqa.selenium.By;
import hooks.Hooks;

public class DashboardPage extends BasePage {

    public boolean hasLogout() {
        try { return driver.findElement(By.linkText("Log Out")).isDisplayed(); }
        catch(Exception e){ return false; }
    }

    public boolean hasAccountTable() {
        return !driver.findElements(By.id("accountTable")).isEmpty();
    }

    public boolean hasBalance() {
        return !driver.findElements(By.cssSelector("#accountTable td:nth-child(2)")).isEmpty();
    }

    public boolean hasRecentTransactions() {
        return !driver.findElements(By.cssSelector(".transactionsTable")).isEmpty();
    }
}
