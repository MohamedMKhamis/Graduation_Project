package tests;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LogoutCacheTest extends BaseTest {

    @Test
    public void verifyDirectUrlAccessBlockedAfterLogout() {
        accountLogin.enterUserName("M.Mahmoud");
        accountLogin.enterPassword("11223344");
        accountLogin.clickLoginButton();

        driver.findElement(By.linkText("Accounts Overview")).click();
        Assert.assertTrue(driver.getPageSource().contains("Accounts Overview"),
                "Account details page should be visible after login.");

        doLogoutIfPresent();
        Assert.assertTrue(driver.getPageSource().contains("Customer Login"),
                "User should be redirected to login page after logout.");

        driver.get("https://parabank.parasoft.com/parabank/overview.htm");

        String pageSource = driver.getPageSource();
        Assert.assertFalse(pageSource.contains("Accounts Overview"),
                "Sensitive account data should not be visible after logout.");
        Assert.assertTrue(pageSource.contains("Customer Login")
                        || pageSource.contains("An internal error has occurred and has been logged."),
                "System should redirect to login or show error after direct URL access.");
    }
}