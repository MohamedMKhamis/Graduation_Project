package tests;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

public class EmptyFieldsTest extends BaseTest {

    @Test
    public void emptyFieldsPreventLogin() {
        accountLogin.clearUsername();
        accountLogin.clearPassword();
        accountLogin.clickLoginButton();

        boolean usernameRequiredShown = !driver.findElements(By.xpath("//*[contains(text(),'Username is required') or contains(text(),'Username is required.')]")).isEmpty();
        boolean passwordRequiredShown = !driver.findElements(By.xpath("//*[contains(text(),'Password is required') or contains(text(),'Password is required.')]")).isEmpty();

        if (!(usernameRequiredShown && passwordRequiredShown)) {
            List generalErrors = driver.findElements(By.xpath("//p[@class='error']"));
            Assert.assertFalse(generalErrors.isEmpty());
        }

        Assert.assertTrue(driver.getCurrentUrl().contains("index.htm") || driver.getTitle().toLowerCase().contains("para"));
    }
}
