package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.Test;

public class IncorrectPasswordTest extends BaseTest {

    @Test
    public void incorrectPasswordShowsErrorAndClearsPassword() {
        String username = "M.Mahmoud";
        String passwordInvalid = "Asdf@123";

        accountLogin.enterUserName(username);
        accountLogin.enterPassword(passwordInvalid);
        accountLogin.clickLoginButton();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//p[@class='error']")));

        String error = accountLogin.getErrorLoginMessage().trim();
        Assert.assertTrue(error.equalsIgnoreCase("Invalid username or password.") || error.toLowerCase().contains("invalid"));

        String passwordValue = driver.findElement(By.cssSelector("input[name='password']")).getAttribute("value");
        Assert.assertTrue(passwordValue == null || passwordValue.isEmpty());
    }
}
