package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.By;
import hooks.Hooks;

public class LoginPage extends BasePage {

    @FindBy(name = "username")
    private WebElement usernameField;

    @FindBy(name = "password")
    private WebElement passwordField;

    @FindBy(css = "input.button")
    private WebElement loginButton;

    private By errorMsg = By.cssSelector("#rightPanel .error");

    public void open() {
        driver.get("https://parabank.parasoft.com/parabank/index.htm");
    }

    public void login(String u, String p) {
        usernameField.clear();
        usernameField.sendKeys(u);
        passwordField.clear();
        passwordField.sendKeys(p);
        loginButton.click();
    }

    public String getError() {
        try {
            return driver.findElement(errorMsg).getText().trim();
        } catch (Exception e) {
            return "";
        }
    }

    public boolean isPasswordCleared() {
        return passwordField.getAttribute("value").isEmpty();
    }
}
