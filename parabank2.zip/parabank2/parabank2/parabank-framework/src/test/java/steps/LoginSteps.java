package steps;

import io.cucumber.java.en.*;
import org.junit.Assert;
import pages.LoginPage;
import pages.DashboardPage;
import hooks.Hooks;

public class LoginSteps {

    LoginPage login = new LoginPage();
    DashboardPage dash = new DashboardPage();

    @Given("the user is on the ParaBank login page")
    public void on_login_page() {
        login.open();
    }

    @When("the user logs in with username {string} and password {string}")
    public void login_user(String u, String p) {
        login.login(u, p);
    }

    @Then("the page title should be {string}")
    public void title_check(String title) {
        Assert.assertEquals(title, Hooks.driver.getTitle());
    }

    @Then("the current URL should end with {string}")
    public void url_check(String u) {
        Assert.assertTrue(Hooks.driver.getCurrentUrl().endsWith(u));
    }

    @Then("the dashboard should display account number, balance and recent transactions")
    public void dashboard_check() {
        Assert.assertTrue(dash.hasAccountTable());
        Assert.assertTrue(dash.hasBalance());
        Assert.assertTrue(dash.hasRecentTransactions());
    }

    @Then("the header should contain a {string} button")
    public void logout_check(String btn) {
        Assert.assertTrue(dash.hasLogout());
    }

    @Then("an error message {string} should be displayed")
    public void invalid_err(String msg) {
        Assert.assertTrue(login.getError().contains(msg) ||
                          login.getError().contains("could not be verified"));
    }

    @Then("no user session should be created")
    public void no_session() {
        Assert.assertFalse(Hooks.driver.getCurrentUrl().contains("overview"));
    }

    @Then("the password field should be cleared")
    public void pass_clear() {
        Assert.assertTrue(login.isPasswordCleared());
    }

    @When("the user attempts to login with username {string} and password {string}")
    public void attempt(String u, String p) {
        login.login(u, p);
    }

    @Then("inline validation message {string} should be shown")
    public void inline_msg(String msg) {
        Assert.assertTrue(Hooks.driver.getPageSource().contains(msg));
    }

    @And("the user opens account details")
    public void open_acc() {
        Hooks.driver.get("https://parabank.parasoft.com/parabank/overview.htm");
    }

    @And("the user clicks logout")
    public void click_logout() {
        Hooks.driver.findElement(org.openqa.selenium.By.linkText("Log Out")).click();
    }

    @When("the user navigates back in the browser")
    public void back() {
        Hooks.driver.navigate().back();
    }

    @Then("no user data should be visible and protected from cached pages")
    public void no_data() {
        Assert.assertFalse(Hooks.driver.getPageSource().contains("Account"));
    }
}
