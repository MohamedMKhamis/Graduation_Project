package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class AccountLogin {
    WebDriver driver;
    WebDriverWait wait;

    public AccountLogin(WebDriver driver){
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(8));
    }

    public void enterUserName(String user){
        WebElement username = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input[name='username']")));
        username.clear();
        username.sendKeys(user);
    }

    public void enterPassword(String pass){
        WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input[name='password']")));
        password.clear();
        password.sendKeys(pass);
    }

    public void clickLoginButton(){
        WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("input[value='Log In']")));
        loginButton.click();
    }

    public void clearUsername(){
        WebElement username = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input[name='username']")));
        username.clear();
    }

    public void clearPassword(){
        WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input[name='password']")));
        password.clear();
    }

    public String getErrorLoginMessage(){
        WebElement errorLoginMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[@class='error']")));
        return errorLoginMessage.getText();
    }
}
