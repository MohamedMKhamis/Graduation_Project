package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.Test;

public class InvalidUsernameTest extends BaseTest {

    @Test
    public void invalidUsernameShowsError() {
        String username = "fakeUser";
        String password = "11223344";

        accountLogin.enterUserName(username);
        accountLogin.enterPassword(password);
        accountLogin.clickLoginButton();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//p[@class='error']")));

        String error = accountLogin.getErrorLoginMessage().trim();
        Assert.assertTrue(error.equalsIgnoreCase("Invalid username or password.") || error.toLowerCase().contains("invalid"));

        String currentUrl = driver.getCurrentUrl();
        Assert.assertFalse(currentUrl.contains("/overview.htm"));
    }
}
