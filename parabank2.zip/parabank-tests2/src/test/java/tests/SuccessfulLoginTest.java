package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.List;

public class SuccessfulLoginTest extends BaseTest {

    @Test
    public void successfulLoginShowsDashboard() {

        SoftAssert softAssert = new SoftAssert();

        String username = "M.Mahmoud";
        String password = "11223344";

        accountLogin.enterUserName(username);
        accountLogin.enterPassword(password);
        accountLogin.clickLoginButton();

        wait.until(ExpectedConditions.or(
                ExpectedConditions.titleContains("ParaBank | Accounts Overview"),
                ExpectedConditions.urlContains("/overview.htm"),
                ExpectedConditions.presenceOfElementLocated(By.xpath("//h1[contains(text(),'Accounts Overview')]"))
        ));

        String title = driver.getTitle().trim();

        softAssert.assertTrue(
                title.equals("ParaBank | Accounts Overview") ||
                        title.equals("ParaBank | Accounts Overview."),
                "Page title mismatch. Actual: '" + title + "'"
        );

        String currentUrl = driver.getCurrentUrl();
        softAssert.assertTrue(
                currentUrl.contains("/overview.htm"),
                "URL does not contain /overview.htm. Actual: " + currentUrl
        );

        List<?> accountRows = driver.findElements(By.xpath("//div[@id='rightPanel']//table//tr"));
        softAssert.assertTrue(
                accountRows.size() > 1,
                "Account table rows not found on dashboard."
        );

        boolean logoutExists = !driver.findElements(By.linkText("Log Out")).isEmpty();
        softAssert.assertTrue(
                logoutExists,
                "Logout button/link not found."
        );

        softAssert.assertAll();
    }
}
