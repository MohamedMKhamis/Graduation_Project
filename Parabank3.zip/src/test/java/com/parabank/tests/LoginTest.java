package com.parabank.tests;
import com.parabank.core.BaseTest;
import com.parabank.pages.DashboardPage;
import com.parabank.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.Test;
public class LoginTest extends BaseTest {
    private final String baseUrl = "https://parabank.parasoft.com/parabank/index.htm";
    @Test(description = "Verify successful login shows title, URL and dashboard elements")
    public void successfulLoginShowsDashboard() {
        LoginPage login = new LoginPage(driver);
        login.open(baseUrl);
        login.setUsername("M.Mahmoud");
        login.setPassword("11223344");
        login.clickLogin();
        DashboardPage dash = new DashboardPage(driver);
        Assert.assertTrue(driver.getTitle().contains("ParaBank | Accounts Overview"), "Title did not match");
        Assert.assertTrue(driver.getCurrentUrl().endsWith("/overview.htm"), "URL does not end with /overview.htm");
        Assert.assertTrue(dash.hasAccountNumber(), "Account number not displayed");
        Assert.assertTrue(dash.hasBalance(), "Balance not displayed");
        Assert.assertTrue(dash.hasRecentTransactions(), "Recent transactions not displayed");
        Assert.assertTrue(dash.hasLogout(), "Logout link not found");
    }
    @Test(description = "Verify invalid username is denied login")
    public void invalidUsernameDenied() {
        LoginPage login = new LoginPage(driver);
        login.open(baseUrl);
        login.setUsername("fakeUser");
        login.setPassword("11223344");
        login.clickLogin();
        String err = login.getErrorMessage();
        Assert.assertTrue(err.toLowerCase().contains("invalid username or password"), "Unexpected error: " + err);
        Assert.assertTrue(login.isOnLoginPage(), "User should remain on login page");
    }
    @Test(description = "Verify incorrect password is denied login")
    public void incorrectPasswordDenied() {
        LoginPage login = new LoginPage(driver);
        login.open(baseUrl);
        login.setUsername("M.Mahmoud");
        login.setPassword("Asdf@123");
        login.clickLogin();
        String err = login.getErrorMessage();
        Assert.assertTrue(err.toLowerCase().contains("invalid username or password"), "Unexpected error: " + err);
        Assert.assertTrue(login.isOnLoginPage(), "User should remain on login page");
    }
    @Test(description = "Verify empty credentials prevented")
    public void emptyCredentialsPrevented() {
        LoginPage login = new LoginPage(driver);
        login.open(baseUrl);
        login.setUsername(""); 
        login.setPassword(""); 
        login.clickLogin();
        String err = login.getErrorMessage();
        Assert.assertTrue(login.isOnLoginPage(), "User should remain on login page");
        Assert.assertTrue(err.toLowerCase().contains("username is required") || err.toLowerCase().contains("password is required") || err.length() == 0, "Expected inline validation or no navigation, got: " + err);
    }
    @Test(description = "Verify no sensitive data shown after logout")
    public void sensitiveDataNotDisplayedAfterLogout() {
        LoginPage login = new LoginPage(driver);
        login.open(baseUrl);
        login.setUsername("M.Mahmoud");
        login.setPassword("11223344");
        login.clickLogin();
        DashboardPage dash = new DashboardPage(driver);
        Assert.assertTrue(dash.hasLogout(), "Logout not present to log out");
        driver.findElementByLinkText("Log Out").click();
        driver.navigate().back();
        Assert.assertFalse(dash.hasAccountNumber(), "Account data visible after logout/back");
    }
}
