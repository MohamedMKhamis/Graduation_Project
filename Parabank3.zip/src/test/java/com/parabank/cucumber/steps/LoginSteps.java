package com.parabank.cucumber.steps;
import com.parabank.pages.DashboardPage;
import com.parabank.pages.LoginPage;
import com.parabank.core.BaseTest;
import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
public class LoginSteps extends BaseTest {
    private LoginPage login;
    private DashboardPage dash;
    private final String baseUrl = "https://parabank.parasoft.com/parabank/index.htm";
    @Given("the login page is open")
    public void the_login_page_is_open() {
        setUp();
        login = new LoginPage(driver);
        login.open(baseUrl);
    }
    @Given("I log in with username {string} and password {string}")
    public void i_log_in_with_username_and_password(String username, String password) {
        login.setUsername(username);
        login.setPassword(password);
        login.clickLogin();
        dash = new DashboardPage(driver);
    }
    @Then("the page title should contain {string}")
    public void the_page_title_should_contain(String expected) {
        Assert.assertTrue(driver.getTitle().contains(expected));
    }
    @Then("the URL should end with {string}")
    public void the_url_should_end_with(String suffix) {
        Assert.assertTrue(driver.getCurrentUrl().endsWith(suffix));
    }
    @Then("the dashboard should show account number, balance and recent transactions")
    public void the_dashboard_should_show_account_number_balance_and_recent_transactions() {
        Assert.assertTrue(dash.hasAccountNumber());
        Assert.assertTrue(dash.hasBalance());
        Assert.assertTrue(dash.hasRecentTransactions());
    }
    @Then("the header should contain a {string} button")
    public void the_header_should_contain_a_button(String text) {
        Assert.assertTrue(dash.hasLogout());
    }
    @Then("I should see an error message {string}")
    public void i_should_see_an_error_message(String msg) {
        String err = login.getErrorMessage();
        Assert.assertTrue(err.toLowerCase().contains(msg.toLowerCase()));
    }
    @Then("I should remain on the login page")
    public void i_should_remain_on_the_login_page() {
        Assert.assertTrue(login.isOnLoginPage());
    }
    @Then("the password field should be cleared")
    public void the_password_field_should_be_cleared() {
        String pwd = driver.findElement(By.name("password")).getAttribute("value");
        Assert.assertTrue(pwd == null || pwd.isEmpty());
    }
    @Then("inline validation should show {string} and {string}")
    public void inline_validation_should_show_and(String uMsg, String pMsg) {
        String err = login.getErrorMessage();
        Assert.assertTrue(err.toLowerCase().contains("username is required") || err.toLowerCase().contains("password is required") || err.isEmpty());
    }
    @When("I log out")
    public void i_log_out() {
        driver.findElement(By.linkText("Log Out")).click();
    }
    @When("I navigate back in the browser")
    public void i_navigate_back_in_the_browser() {
        driver.navigate().back();
    }
    @Then("no user information should be visible")
    public void no_user_information_should_be_visible() {
        Assert.assertFalse(dash.hasAccountNumber());
    }
    @After
    public void cleanup() {
        tearDown();
    }
}
