package com.parabank.pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
public class DashboardPage {
    private WebDriver driver;
    private WebDriverWait wait;
    private By accountsOverviewHeading = By.xpath("//h1[contains(text(),'Accounts Overview') or contains(text(),'Overview')]"); 
    private By accountNumber = By.cssSelector(".balance .number, .accountNumber, #accountTable td a");
    private By balance = By.cssSelector(".balance .currency, .balance");
    private By recentTransactions = By.cssSelector("#transactionTable, .transactions, .recentTransactions");
    private By logoutLink = By.linkText("Log Out");
    public DashboardPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }
    public boolean isAtOverview() {
        try {
            return wait.until(ExpectedConditions.titleContains("Accounts Overview")) || driver.getCurrentUrl().endsWith("/overview.htm");
        } catch (Exception e) {
            return false;
        }
    }
    public boolean hasAccountNumber() {
        try {
            return !driver.findElements(accountNumber).isEmpty();
        } catch (Exception e) {
            return false;
        }
    }
    public boolean hasBalance() {
        try {
            return !driver.findElements(balance).isEmpty();
        } catch (Exception e) {
            return false;
        }
    }
    public boolean hasRecentTransactions() {
        try {
            return !driver.findElements(recentTransactions).isEmpty();
        } catch (Exception e) {
            return false;
        }
    }
    public boolean hasLogout() {
        try {
            return !driver.findElements(logoutLink).isEmpty();
        } catch (Exception e) {
            return false;
        }
    }
}
