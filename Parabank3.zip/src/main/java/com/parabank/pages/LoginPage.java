package com.parabank.pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
public class LoginPage {
    private WebDriver driver;
    private WebDriverWait wait;
    private By usernameInput = By.name("username");
    private By passwordInput = By.name("password");
    private By loginButton = By.cssSelector("input[type='submit'][value='Log In'], input[value='Log In']");
    private By errorMessage = By.cssSelector("#rightPanel .error, .error, .message.error");
    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }
    public void open(String url) {
        driver.get(url);
    }
    public void setUsername(String username) {
        WebElement el = wait.until(ExpectedConditions.visibilityOfElementLocated(usernameInput));
        el.clear();
        el.sendKeys(username);
    }
    public void setPassword(String password) {
        WebElement el = wait.until(ExpectedConditions.visibilityOfElementLocated(passwordInput));
        el.clear();
        el.sendKeys(password);
    }
    public void clickLogin() {
        WebElement el = wait.until(ExpectedConditions.elementToBeClickable(loginButton));
        el.click();
    }
    public String getErrorMessage() {
        try {
            return wait.until(ExpectedConditions.visibilityOfElementLocated(errorMessage)).getText().trim();
        } catch (Exception e) {
            return "";
        }
    }
    public boolean isOnLoginPage() {
        return driver.getTitle().toLowerCase().contains("parabank") && (driver.getCurrentUrl().toLowerCase().contains("login") || driver.getCurrentUrl().toLowerCase().contains("index"));
    }
}
